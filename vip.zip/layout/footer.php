	<!-- Footer Style Five / Style Two -->
    <footer class="footer-style-five style-two">

		<!-- Footer Bottom -->
		<div class="footer-bottom">
			<div class="auto-container">
				<div class="row clearfix">
					<!-- Column -->
					<div class="column col-lg-6 col-md-12 col-sm-12">
						<div class="copyright">&copy; 2023 <a href="#">Schnur Group & Investal24</a>. All Rights Reserved.</div>
					</div>
					<!-- Column -->
					<div class="column col-lg-6 col-md-12 col-sm-12">
						<!-- Scroll To Top -->
						<div class="scroll-top scroll-to-target" data-target="html">Scrool Top  <span class="fa fa-angle-up"></span></div>
					</div>
				</div>
			</div>
		</div>
		
	</footer>
	<!-- End Footer Style Five -->